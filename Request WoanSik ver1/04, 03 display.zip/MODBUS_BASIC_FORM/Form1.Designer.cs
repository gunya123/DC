﻿namespace MODBUS_BASIC_FORM
{
    partial class adress06
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adress06));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.responseTimer = new System.Windows.Forms.Timer(this.components);
            this.receiveBox = new System.Windows.Forms.TextBox();
            this.writeBox = new System.Windows.Forms.TextBox();
            this.errorBox = new System.Windows.Forms.TextBox();
            this.request06 = new System.Windows.Forms.Button();
            this.timer03 = new System.Windows.Forms.Timer(this.components);
            this.timer06Stop = new System.Windows.Forms.Button();
            this.errorBoxCon = new System.Windows.Forms.TextBox();
            this.timerWait = new System.Windows.Forms.Timer(this.components);
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.screen03 = new System.Windows.Forms.TabPage();
            this.screen04 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.파일ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.종료ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.포트설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.로그확인ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.data06Box = new System.Windows.Forms.TextBox();
            this.adressBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.screen03.SuspendLayout();
            this.screen04.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // responseTimer
            // 
            this.responseTimer.Tick += new System.EventHandler(this.responseTimer_Tick);
            // 
            // receiveBox
            // 
            this.receiveBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.receiveBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.receiveBox.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.receiveBox.ForeColor = System.Drawing.Color.White;
            this.receiveBox.Location = new System.Drawing.Point(234, 416);
            this.receiveBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.receiveBox.Name = "receiveBox";
            this.receiveBox.Size = new System.Drawing.Size(75, 22);
            this.receiveBox.TabIndex = 4;
            this.receiveBox.Text = "Received";
            // 
            // writeBox
            // 
            this.writeBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.writeBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.writeBox.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.writeBox.ForeColor = System.Drawing.Color.White;
            this.writeBox.Location = new System.Drawing.Point(315, 416);
            this.writeBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.writeBox.Name = "writeBox";
            this.writeBox.Size = new System.Drawing.Size(75, 22);
            this.writeBox.TabIndex = 5;
            this.writeBox.Text = "Write";
            // 
            // errorBox
            // 
            this.errorBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.errorBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errorBox.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.errorBox.ForeColor = System.Drawing.Color.Red;
            this.errorBox.Location = new System.Drawing.Point(234, 339);
            this.errorBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.errorBox.Name = "errorBox";
            this.errorBox.Size = new System.Drawing.Size(139, 21);
            this.errorBox.TabIndex = 17;
            this.errorBox.Text = "None Error";
            // 
            // request06
            // 
            this.request06.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("request06.BackgroundImage")));
            this.request06.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.request06.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.request06.Font = new System.Drawing.Font("나눔스퀘어_ac", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.request06.ForeColor = System.Drawing.Color.White;
            this.request06.Location = new System.Drawing.Point(234, 147);
            this.request06.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.request06.Name = "request06";
            this.request06.Size = new System.Drawing.Size(98, 40);
            this.request06.TabIndex = 19;
            this.request06.Text = "적용하기";
            this.request06.UseVisualStyleBackColor = true;
            this.request06.Click += new System.EventHandler(this.request06_Click);
            // 
            // timer03
            // 
            this.timer03.Interval = 1000;
            this.timer03.Tick += new System.EventHandler(this.timer03_Tick);
            // 
            // timer06Stop
            // 
            this.timer06Stop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("timer06Stop.BackgroundImage")));
            this.timer06Stop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.timer06Stop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.timer06Stop.Font = new System.Drawing.Font("나눔스퀘어_ac", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.timer06Stop.ForeColor = System.Drawing.Color.White;
            this.timer06Stop.Location = new System.Drawing.Point(234, 206);
            this.timer06Stop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.timer06Stop.Name = "timer06Stop";
            this.timer06Stop.Size = new System.Drawing.Size(115, 40);
            this.timer06Stop.TabIndex = 21;
            this.timer06Stop.Text = "타이머 on/off";
            this.timer06Stop.UseVisualStyleBackColor = true;
            this.timer06Stop.Click += new System.EventHandler(this.timer06Stop_Click);
            // 
            // errorBoxCon
            // 
            this.errorBoxCon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.errorBoxCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errorBoxCon.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.errorBoxCon.ForeColor = System.Drawing.Color.Red;
            this.errorBoxCon.Location = new System.Drawing.Point(234, 385);
            this.errorBoxCon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.errorBoxCon.Name = "errorBoxCon";
            this.errorBoxCon.Size = new System.Drawing.Size(139, 21);
            this.errorBoxCon.TabIndex = 31;
            this.errorBoxCon.Text = "Error Contents";
            // 
            // timerWait
            // 
            this.timerWait.Interval = 150;
            this.timerWait.Tick += new System.EventHandler(this.timerWait_Tick);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(234, 293);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 22);
            this.textBox12.TabIndex = 34;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(58)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(16)))), ((int)(((byte)(31)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.DarkOrange;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.GridColor = System.Drawing.Color.Silver;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(36)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(197, 393);
            this.dataGridView1.TabIndex = 39;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.screen03);
            this.tabControl1.Controls.Add(this.screen04);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.tabControl1.Location = new System.Drawing.Point(0, 25);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(211, 426);
            this.tabControl1.TabIndex = 40;
            // 
            // screen03
            // 
            this.screen03.BackColor = System.Drawing.Color.Transparent;
            this.screen03.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.screen03.Controls.Add(this.dataGridView1);
            this.screen03.ForeColor = System.Drawing.Color.Black;
            this.screen03.Location = new System.Drawing.Point(4, 23);
            this.screen03.Name = "screen03";
            this.screen03.Padding = new System.Windows.Forms.Padding(3);
            this.screen03.Size = new System.Drawing.Size(203, 399);
            this.screen03.TabIndex = 0;
            this.screen03.Text = "Screen 03번";
            // 
            // screen04
            // 
            this.screen04.BackColor = System.Drawing.Color.Transparent;
            this.screen04.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.screen04.Controls.Add(this.dataGridView2);
            this.screen04.Location = new System.Drawing.Point(4, 23);
            this.screen04.Name = "screen04";
            this.screen04.Padding = new System.Windows.Forms.Padding(3);
            this.screen04.Size = new System.Drawing.Size(203, 399);
            this.screen04.TabIndex = 1;
            this.screen04.Text = "Screen 04번";
            this.screen04.Click += new System.EventHandler(this.screen04_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(58)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(16)))), ((int)(((byte)(32)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(24)))), ((int)(((byte)(36)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.SandyBrown;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(197, 393);
            this.dataGridView2.TabIndex = 41;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.menuStrip1.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 9.749998F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파일ToolStripMenuItem,
            this.설정ToolStripMenuItem,
            this.로그확인ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(410, 25);
            this.menuStrip1.TabIndex = 41;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 파일ToolStripMenuItem
            // 
            this.파일ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.종료ToolStripMenuItem});
            this.파일ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.파일ToolStripMenuItem.Name = "파일ToolStripMenuItem";
            this.파일ToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.파일ToolStripMenuItem.Text = "파일";
            // 
            // 종료ToolStripMenuItem
            // 
            this.종료ToolStripMenuItem.Name = "종료ToolStripMenuItem";
            this.종료ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.종료ToolStripMenuItem.Text = "종료";
            // 
            // 설정ToolStripMenuItem
            // 
            this.설정ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.포트설정ToolStripMenuItem});
            this.설정ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.설정ToolStripMenuItem.Name = "설정ToolStripMenuItem";
            this.설정ToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.설정ToolStripMenuItem.Text = "설정";
            // 
            // 포트설정ToolStripMenuItem
            // 
            this.포트설정ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.포트설정ToolStripMenuItem.Name = "포트설정ToolStripMenuItem";
            this.포트설정ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.포트설정ToolStripMenuItem.Text = "포트 설정";
            this.포트설정ToolStripMenuItem.Click += new System.EventHandler(this.포트설정ToolStripMenuItem_Click);
            // 
            // 로그확인ToolStripMenuItem
            // 
            this.로그확인ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.로그확인ToolStripMenuItem.Name = "로그확인ToolStripMenuItem";
            this.로그확인ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.로그확인ToolStripMenuItem.Text = "로그 확인";
            this.로그확인ToolStripMenuItem.Click += new System.EventHandler(this.로그확인ToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(234, 318);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 21);
            this.label1.TabIndex = 42;
            this.label1.Text = "에러 횟수";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(234, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 21);
            this.label2.TabIndex = 43;
            this.label2.Text = "에러 내용";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(234, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 21);
            this.label3.TabIndex = 44;
            this.label3.Text = "cnt check";
            // 
            // data06Box
            // 
            this.data06Box.Location = new System.Drawing.Point(234, 118);
            this.data06Box.Name = "data06Box";
            this.data06Box.Size = new System.Drawing.Size(100, 22);
            this.data06Box.TabIndex = 45;
            this.data06Box.Text = "0";
            // 
            // adressBox
            // 
            this.adressBox.Location = new System.Drawing.Point(234, 70);
            this.adressBox.Name = "adressBox";
            this.adressBox.Size = new System.Drawing.Size(100, 22);
            this.adressBox.TabIndex = 46;
            this.adressBox.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label4.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(234, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 23);
            this.label4.TabIndex = 47;
            this.label4.Text = "Adress 값";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label5.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(234, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 23);
            this.label5.TabIndex = 48;
            this.label5.Text = "Value 값";
            // 
            // adress06
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImage = global::MODBUS_BASIC_FORM.Properties.Resources.pattern_369543_1280___dark;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(410, 451);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.adressBox);
            this.Controls.Add(this.data06Box);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.errorBox);
            this.Controls.Add(this.errorBoxCon);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.writeBox);
            this.Controls.Add(this.timer06Stop);
            this.Controls.Add(this.receiveBox);
            this.Controls.Add(this.request06);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "adress06";
            this.Text = " q";
            this.Load += new System.EventHandler(this.adress06_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.screen03.ResumeLayout(false);
            this.screen04.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer responseTimer;
        private System.Windows.Forms.TextBox receiveBox;
        private System.Windows.Forms.TextBox writeBox;
        private System.Windows.Forms.TextBox errorBox;
        private System.Windows.Forms.Button request06;
        private System.Windows.Forms.Timer timer03;
        private System.Windows.Forms.Button timer06Stop;
        private System.Windows.Forms.TextBox errorBoxCon;
        private System.Windows.Forms.Timer timerWait;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage screen03;
        private System.Windows.Forms.TabPage screen04;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 파일ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 종료ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 포트설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 로그확인ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox data06Box;
        private System.Windows.Forms.TextBox adressBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

