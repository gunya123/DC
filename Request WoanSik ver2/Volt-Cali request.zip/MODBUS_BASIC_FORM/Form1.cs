﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace MODBUS_BASIC_FORM
{
    public partial class adress06 : Form
    {
        SerialPortSetting SP = new SerialPortSetting();
        Crc16 c1 = new Crc16(); //crc 클래스 객체
        Log logForm = new Log();
        bool wideMode = false;
        static string txBuf = null;
        byte[] writeCRC = new byte[1024]; //TX crc 버퍼
        byte[] data = new byte[255];
        byte[] data04 = new byte[255];
        byte[] _SPbuffer = new byte[255];
        static byte packetRange = 0x0A;
        //port setting
        string port; //포트 이름
        int baud_rate;
        int data_bit;
        bool _03mode = false;
        bool serialPort_setting = false; //포트 세팅 적용을 알리는 flag
        bool serialOpenCheck = false; //포트 Open 상태 flag
        int error = 0;
        int numReceviedData = 0;
        int numReceviedDataBuf = 0;
        int bytesToRead = 1; // 1개씩 바이트를 읽어오도록 시킨다.
        int waitCnt = 0;
        int cellCnt = 0;
        bool flag = false; // RX의 while문을 제어한다.
        bool idle = true;
        bool isTimerActive = false;
        bool flag03 = false;
        bool flag04 = false;
        bool flag06 = false;
        bool print_comLog = true;
        int cnt = 0; // RX를 신호를 위한 cnt를 초기화
        int responseCnt = 0;

        byte[] _send03Buf =
        {
            0x01,
            0x03,
            0x00, 0x00,
            0x00, 0x0A,
        };

        byte[] _send04Buf =
        {
            0x01,
            0x04,
            0x00, 0x00,
            0x00, 0x0A,
        };

        byte[] _send06Buf =
        {
            0x01,
            0x06,
            0x00, 0x01,
            0x00, 0xAA
        };

        public adress06()
        {
            InitializeComponent();
            
            logForm.form2LogBox.TextChanged += logBox_TextChanged;
            //Controls.Add(logBox);
        }

        private void logBox_TextChanged(object sender, EventArgs e)
        {
            // 텍스트가 변경될 때마다 스크롤을 맨 아래로 이동
            logForm.form2LogBox.SelectionStart = logForm.form2LogBox.Text.Length;
            logForm.form2LogBox.ScrollToCaret();
        }


        /*
        private void portConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (!serialPort1.IsOpen)
                {
                    serialPort1.PortName = comboBox_port.Text;
                    serialPort1.BaudRate = 9600;
                    serialPort1.DataBits = 8; // 우리가 총 8개의 비트를 보내기 때문에 8로 지정.
                    serialPort1.StopBits = StopBits.One;
                    serialPort1.Parity = Parity.None;
                    serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived); //이것이 꼭 필요하다
                    serialPort1.Open();  //시리얼포트 열기 
                    portConnect.Text = "포트닫기";
                    //timer03.Start();
                    timer06Stop.Text = "timer03 Stop";
                }
                else
                {
                    portConnect.Text = "포트열기";
                    timer03.Stop();
                    serialPort1.Close();
                    serialPort1.DataReceived -= new SerialDataReceivedEventHandler(serialPort1_DataReceived); // 끌 때 꼭 이벤트도 같이 꺼줘야 한다. 안그러면 중복 발생함.
                }
            }
            catch (UnauthorizedAccessException)
            {
                errorMess.Text = "포트에 대한 액세스가 거부";
            }

            catch (Exception)
            {
                error_Messeage("시리얼포트 오류");
            }
        }
        */
        private void SerialPort_Write(byte[] writeBuffer) //SerialPort 송신 함수
        {
            try
            {
                responseTimer.Start();
                writeBox.Text = "쓰기 시작";

                writeCRC = c1.crc16(writeBuffer, 6); //CRC 계산
                serialPort1.Write(writeBuffer, 0, 6); //데이터 전송
                serialPort1.Write(writeCRC, 0, 2); //CRC 전송

                DisplayPacket(writeBuffer);
                DisplayPacket(writeCRC);
                if (logForm.print_comLog)
                {
                    logForm.form2LogBox.Text += "Tx : " + txBuf.Remove(txBuf.Length - 6) + Environment.NewLine; // $"{DateTime.Now:yy.MM.dd_HH:mm:ss tt}" + 
                }

                txBuf = null;
            }
            catch (Exception)
            {
                error_Messeage("쓰기 오류");
            }
        }

        static void DisplayPacket(byte[] packet)
        {
            foreach (byte b in packet)
            {
                txBuf += ($"{b:X2} "); // 띄어쓰기를 해줘야 예쁘게 출력됨 
            }
        }


        private void responseTimer_Tick(object sender, EventArgs e)
        {
            responseCnt++;
            if (responseCnt >= 15)
            {
                error_Messeage("응답 시간 초과");
                responseCnt = 0;
                responseTimer.Stop();
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e) //SerialPort Thread 와 메인 Thread 충돌 회피를 위한 Invoke 함수
        {
            responseCnt = 0;
            //receiveBox.Text = "받기 시작";
            responseTimer.Stop();



            if (InvokeRequired)
            {
                Invoke(new EventHandler(MySerialReceived));
            }
        }

        //
        // 받은 데이터를 처리하는 곳
        //
        private void MySerialReceived(object s, EventArgs e)
        {
            try
            {
                while (true)
                {

                    if (flag06)
                    {
                        cnt = 0;
                        numReceviedData = 0;
                        requestProcesser(8);
                        flag06 = false;
                        idle = true;
                        _03mode = false;
                        break;
                    }
                    else if (flag04)
                    {
                        cnt = 0;
                        numReceviedData = 0;
                        requestProcesser(25);
                        flag04 = false;
                        idle = true;
                        _03mode = true;
                        break;
                    }
                    else if (flag03)
                    {
                        cnt = 0;
                        numReceviedData = 0;
                        requestProcesser(25);
                        flag03 = false;
                        idle = true;
                        break;
                    }

                    else
                    {
                        error++;
                        errorBox.Text = error.ToString();
                        errorBoxCon.Text = "MyReceived 에러";
                        idle = true;
                        flag03 = false;
                        flag04 = false;
                        flag06 = false;
                        break;
                    }
                }

            }

            catch (Exception)
            {
                error_Messeage("받기 오류");
                idle = true;
            }

        }

        private void requestProcesser(int range)
        {

            while (true)
            {
                numReceviedData = numReceviedData + serialPort1.BytesToRead;
                serialPort1.Read(_SPbuffer, cnt, 1);
                cnt++;
                textBox12.Text = cnt.ToString();
                if (cnt > 1)
                {
                    if (_SPbuffer[1] == 0x03 || _SPbuffer[1] == 0x04 || _SPbuffer[1] == 0x06)
                    {
                        if (cnt >= range)
                        {
                            numReceviedData = numReceviedData - range;
                            cnt = cnt - range;
                            if (flag03 || flag04)
                            {
                                grid_process(_SPbuffer);
                            }
                            byte[] truncatedArray = _SPbuffer.Take(range).ToArray();
                            ProcessPacket(truncatedArray);
                            break;
                        }
                    }
                    else
                    {
                        if (flag03)
                        {
                            error_Messeage("03 Receive 에러");
                            int remove = serialPort1.BytesToRead;
                            serialPort1.Read(_SPbuffer, cnt, remove);
                            byte[] truncatedArray = _SPbuffer.Take(remove + 2).ToArray();
                            ProcessPacket(truncatedArray);
                            break;
                        }
                        else if (flag04)
                        {
                            error_Messeage("04 Receive 에러");
                            int remove = serialPort1.BytesToRead;
                            serialPort1.Read(_SPbuffer, cnt, remove);
                            byte[] truncatedArray = _SPbuffer.Take(remove + 2).ToArray();
                            ProcessPacket(truncatedArray);
                            break;
                        }
                        else
                        {
                            error_Messeage("06 Receive 에러");
                            int remove = serialPort1.BytesToRead;
                            serialPort1.Read(_SPbuffer, cnt, remove);
                            byte[] truncatedArray = _SPbuffer.Take(remove + 2).ToArray();
                            ProcessPacket(truncatedArray);
                            break;
                        }
                    }
                }
            }
        }


        private void grid_process(byte[] buffer)
        {
            while (true)
            {
                if (flag03)
                {
                    float floatValue = ((buffer[cellCnt * 2 + 3] << 8) + (buffer[cellCnt * 2 + 4]));
                    valueBox.Text = (floatValue / 1000.0f).ToString() + "V";
                    break;
                }
                else
                {
                    caliBox.Text = ((buffer[3] << 8) + (buffer[4])).ToString();
                    cycleBox.Text = ((buffer[5] << 8) + (buffer[6])).ToString();
                    break;
                }
                
                
            }
        }

        private void error_Messeage(string msg)
        {
            errorBoxCon.Text = msg;
            error++;
            errorBox.Text = error.ToString();
        }

        private void ProcessPacket(byte[] packet)
        {
            string resultRx = BitConverter.ToString(packet).Replace("-", " ");
            if (logForm.print_comLog)
            {
                logForm.form2LogBox.Text += "Rx : " + $"{resultRx}" + Environment.NewLine;
            }
        }

        private void packet06_changer(int adress, int data)
        {
            if (data > 255)
            {
               byte[] byteData = BitConverter.GetBytes(data);
                _send06Buf[4] = byteData[1];
                _send06Buf[5] = byteData[0];
                _send06Buf[3] = (byte)adress;
            }
            else
            {
                _send06Buf[4] = 0x00;
                _send06Buf[5] = (byte)data;
                _send06Buf[3] = (byte)adress;
            }
        }

        private void request06_Click(object sender, EventArgs e)
        {
            try
            {
                if (!isTimerActive)
                {
                    if (idle == true && serialPort1.IsOpen)
                    {
                        idle = false;
                        flag06 = true;
                        packet06_changer(0, Convert.ToInt32(caliBox.Text));
                        SerialPort_Write(_send06Buf);
                    }
                    else if (!serialPort1.IsOpen)
                    {
                        error_Messeage("시리얼 포트 닫힘");
                    }

                    else
                    {
                        error_Messeage("대기 상태 아님");
                    }
                }
            }
            catch
            {
                error_Messeage("06 send Error");
            }
        }

        private void changeCycle_Click(object sender, EventArgs e)
        {
            try
            {
                if (!isTimerActive)
                {
                    if (idle == true && serialPort1.IsOpen)
                    {
                        idle = false;
                        flag06 = true;
                        packet06_changer(1, Convert.ToInt32(cycleBox.Text));
                        SerialPort_Write(_send06Buf);
                    }
                    else if (!serialPort1.IsOpen)
                    {
                        error_Messeage("시리얼 포트 닫힘");
                    }

                    else
                    {
                        error_Messeage("대기 상태 아님");
                    }
                }
            }
            catch
            {
                error_Messeage("06 send Error");
            }
        }

        private void request04_Click(object sender, EventArgs e)
        {
            try
            {
                if (idle == true && serialPort1.IsOpen)
                {
                    idle = false;
                    flag04 = true;

                    SerialPort_Write(_send04Buf);
                }
                else if (!serialPort1.IsOpen)
                {
                    error_Messeage("시리얼 포트 닫힘");
                }

                else
                {
                    error_Messeage("대기 상태 아님");
                }
            }
            catch
            {
                error_Messeage("04 Send Error");
            }
        }

        private void timer03_Tick(object sender, EventArgs e)
        {
            try
            {
                if (idle == true && serialPort1.IsOpen)
                {
                    if (_03mode == true)
                    {
                        timerWait.Start();
                        idle = false;
                        flag03 = true;
                        SerialPort_Write(_send03Buf);
                    }
                    else
                    {
                        timerWait.Start();
                        idle = false;
                        flag04 = true;
                        SerialPort_Write(_send04Buf);
                    }

                }

                else if (!serialPort1.IsOpen)
                {
                    error_Messeage("시리얼 포트 닫힘");
                }

                else if (!idle)
                {
                    error_Messeage("대기 상태 아님");
                }



            }
            catch
            {
                error_Messeage("03 Send Error");
            }
        }

        private void timer06Stop_Click(object sender, EventArgs e)
        {
            if (timer03.Enabled)
            {
                timer03.Stop();
                timer06Stop.Text = "timer03 on";
            }
            else
            {
                timer03.Start();
                timer06Stop.Text = "timer03 Stop";
            }
        }

        private void timerWait_Tick(object sender, EventArgs e)
        {
            isTimerActive = true;
            if (waitCnt <= 0)
            {
                waitCnt++;
            }
            else
            {
                waitCnt = 0;
                timerWait.Stop();
                isTimerActive = false;
            }
        }

        private void CF_FormSendEvent(bool CF_print_comLog) //ComLogForm Send Event
        {
            print_comLog = CF_print_comLog;
        }

        private void SF_FormSendEvent(string SF_port, int SF_baud_rate, int SF_data_bit, bool SF_serialPort_setting) //SerialSettingForm Send Event
        {
            port = SF_port;
            baud_rate = SF_baud_rate;
            data_bit = SF_data_bit;
            serialPort_setting = SF_serialPort_setting;
        }

        
        private void Show_MessageBox(string message, string caption) //스레드 사용하는 메세지 박스
        {
            Thread t = new Thread(() => MessageBox.Show(message, caption));
            t.Start();
        }
        private void Show_ErrorMessageBox(Exception ex) //스레드 사용하는 에러메세지 박스
        {
            Thread t = new Thread(() => MessageBox.Show(ex.Message));
            t.Start();
        }

        private void 로그확인ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            logForm.logTextEvent += new Log.logText(CF_FormSendEvent);
            logForm.Show();
        }

        private void 포트설정ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SP.SettingFormSendEvent += new SerialPortSetting.FormSendDataHandler(SF_FormSendEvent);
            SP.StartPosition = FormStartPosition.Manual; SP.Location = new Point(60, 60);
            SP.ShowDialog();

            try
            {
                if (!serialPort_setting) //flag off 시 return
                { return; }

                if (SP.comboBox.Text == "") //잡은 포트 없을 시 return
                { return; }

                if (serialPort1.IsOpen) //포트가 열려있을 때 버튼 누르면 포트 닫기
                {
                    serialPort1.Close();
                    serialOpenCheck = false;
                    timer03.Stop();
                    //serialPort1.DataReceived -= new SerialDataReceivedEventHandler(serialPort1_DataReceived);
                }
                else
                {
                    serialPort1.PortName = port; //콤보박스의 선택된 COM포트명을 시리얼포트명으로 지정
                    serialPort1.BaudRate = baud_rate;  //보레이트 변경이 필요하면 숫자 변경하기
                    serialPort1.DataBits = data_bit;
                    serialPort1.StopBits = StopBits.One;
                    serialPort1.Parity = Parity.None;
                    serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived); //Invoke한 데이터 Receive
                    serialPort1.Open();
                    serialOpenCheck = true;
                    timer03.Start();
                    timer06Stop.Text = "timer03 Stop";

                    Show_MessageBox("설정값으로 포트 오픈.", "알림");
                }

                SP.portConnect.Text = serialPort1.IsOpen ? "포트 닫기" : "포트 연결"; //포트 상태에 따라 버튼 바꿈
                SP.comboBox.Enabled = !serialPort1.IsOpen; //포트 닫혀 있을 때 포트 설정 변경 가능
                SP.baudRateBox.Enabled = !serialPort1.IsOpen;
                SP.dataBitsBox.Enabled = !serialPort1.IsOpen;
                SP.stopBitBox.Enabled = !serialPort1.IsOpen;
                SP.parityBox.Enabled = !serialPort1.IsOpen;
            }
            catch (Exception ex)
            {
                Show_ErrorMessageBox(ex);
            }
            finally
            {
                serialPort_setting = false;
            }
        }

        private void 종료ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if(!wideMode)
            {
                Width = 450;
                Height = 490;
                wideMode = true;
            }
            else
            {
                Width = 450;
                Height = 260;
                wideMode = false;
            }
        }
    }
}