﻿namespace MODBUS_BASIC_FORM
{
    partial class adress06
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.responseTimer = new System.Windows.Forms.Timer(this.components);
            this.receiveBox = new System.Windows.Forms.TextBox();
            this.writeBox = new System.Windows.Forms.TextBox();
            this.errorBox = new System.Windows.Forms.TextBox();
            this.changeCali = new System.Windows.Forms.Button();
            this.timer03 = new System.Windows.Forms.Timer(this.components);
            this.timer06Stop = new System.Windows.Forms.Button();
            this.errorBoxCon = new System.Windows.Forms.TextBox();
            this.timerWait = new System.Windows.Forms.Timer(this.components);
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.파일ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.종료ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.포트설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.로그확인ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.valueBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.caliBox = new System.Windows.Forms.TextBox();
            this.cycleBox = new System.Windows.Forms.TextBox();
            this.캘리값 = new System.Windows.Forms.Label();
            this.반복횟수 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.changeCycle = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // responseTimer
            // 
            this.responseTimer.Tick += new System.EventHandler(this.responseTimer_Tick);
            // 
            // receiveBox
            // 
            this.receiveBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.receiveBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.receiveBox.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.receiveBox.ForeColor = System.Drawing.Color.White;
            this.receiveBox.Location = new System.Drawing.Point(18, 171);
            this.receiveBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.receiveBox.Name = "receiveBox";
            this.receiveBox.Size = new System.Drawing.Size(75, 22);
            this.receiveBox.TabIndex = 4;
            this.receiveBox.Text = "Received";
            // 
            // writeBox
            // 
            this.writeBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.writeBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.writeBox.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.writeBox.ForeColor = System.Drawing.Color.White;
            this.writeBox.Location = new System.Drawing.Point(99, 171);
            this.writeBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.writeBox.Name = "writeBox";
            this.writeBox.Size = new System.Drawing.Size(75, 22);
            this.writeBox.TabIndex = 5;
            this.writeBox.Text = "Write";
            // 
            // errorBox
            // 
            this.errorBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.errorBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errorBox.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.errorBox.ForeColor = System.Drawing.Color.Red;
            this.errorBox.Location = new System.Drawing.Point(18, 94);
            this.errorBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.errorBox.Name = "errorBox";
            this.errorBox.Size = new System.Drawing.Size(156, 21);
            this.errorBox.TabIndex = 17;
            this.errorBox.Text = "None Error";
            // 
            // changeCali
            // 
            this.changeCali.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.changeCali.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.changeCali.Font = new System.Drawing.Font("나눔스퀘어_ac", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.changeCali.ForeColor = System.Drawing.Color.White;
            this.changeCali.Location = new System.Drawing.Point(144, 34);
            this.changeCali.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.changeCali.Name = "changeCali";
            this.changeCali.Size = new System.Drawing.Size(88, 38);
            this.changeCali.TabIndex = 19;
            this.changeCali.Text = "적용하기";
            this.changeCali.UseVisualStyleBackColor = true;
            this.changeCali.Click += new System.EventHandler(this.request06_Click);
            // 
            // timer03
            // 
            this.timer03.Interval = 1000;
            this.timer03.Tick += new System.EventHandler(this.timer03_Tick);
            // 
            // timer06Stop
            // 
            this.timer06Stop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.timer06Stop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.timer06Stop.Font = new System.Drawing.Font("나눔스퀘어_ac", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.timer06Stop.ForeColor = System.Drawing.Color.White;
            this.timer06Stop.Location = new System.Drawing.Point(24, 235);
            this.timer06Stop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.timer06Stop.Name = "timer06Stop";
            this.timer06Stop.Size = new System.Drawing.Size(115, 40);
            this.timer06Stop.TabIndex = 21;
            this.timer06Stop.Text = "타이머 on/off";
            this.timer06Stop.UseVisualStyleBackColor = true;
            this.timer06Stop.Click += new System.EventHandler(this.timer06Stop_Click);
            // 
            // errorBoxCon
            // 
            this.errorBoxCon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(20)))), ((int)(((byte)(40)))));
            this.errorBoxCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errorBoxCon.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.errorBoxCon.ForeColor = System.Drawing.Color.Red;
            this.errorBoxCon.Location = new System.Drawing.Point(18, 140);
            this.errorBoxCon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.errorBoxCon.Name = "errorBoxCon";
            this.errorBoxCon.Size = new System.Drawing.Size(156, 21);
            this.errorBoxCon.TabIndex = 31;
            this.errorBoxCon.Text = "Error Contents";
            // 
            // timerWait
            // 
            this.timerWait.Interval = 150;
            this.timerWait.Tick += new System.EventHandler(this.timerWait_Tick);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(18, 48);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(156, 22);
            this.textBox12.TabIndex = 34;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.menuStrip1.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 9.749998F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파일ToolStripMenuItem,
            this.설정ToolStripMenuItem,
            this.로그확인ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(434, 25);
            this.menuStrip1.TabIndex = 41;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 파일ToolStripMenuItem
            // 
            this.파일ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.종료ToolStripMenuItem});
            this.파일ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.파일ToolStripMenuItem.Name = "파일ToolStripMenuItem";
            this.파일ToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.파일ToolStripMenuItem.Text = "파일";
            // 
            // 종료ToolStripMenuItem
            // 
            this.종료ToolStripMenuItem.Name = "종료ToolStripMenuItem";
            this.종료ToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.종료ToolStripMenuItem.Text = "종료";
            // 
            // 설정ToolStripMenuItem
            // 
            this.설정ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.포트설정ToolStripMenuItem});
            this.설정ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.설정ToolStripMenuItem.Name = "설정ToolStripMenuItem";
            this.설정ToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.설정ToolStripMenuItem.Text = "설정";
            // 
            // 포트설정ToolStripMenuItem
            // 
            this.포트설정ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.포트설정ToolStripMenuItem.Name = "포트설정ToolStripMenuItem";
            this.포트설정ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.포트설정ToolStripMenuItem.Text = "포트 설정";
            this.포트설정ToolStripMenuItem.Click += new System.EventHandler(this.포트설정ToolStripMenuItem_Click);
            // 
            // 로그확인ToolStripMenuItem
            // 
            this.로그확인ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.로그확인ToolStripMenuItem.Name = "로그확인ToolStripMenuItem";
            this.로그확인ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.로그확인ToolStripMenuItem.Text = "로그 확인";
            this.로그확인ToolStripMenuItem.Click += new System.EventHandler(this.로그확인ToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(18, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 21);
            this.label1.TabIndex = 42;
            this.label1.Text = "에러 횟수";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(18, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 21);
            this.label2.TabIndex = 43;
            this.label2.Text = "에러 내용";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("한컴 말랑말랑 Regular", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(16, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 21);
            this.label3.TabIndex = 44;
            this.label3.Text = "cnt check";
            // 
            // valueBox
            // 
            this.valueBox.Location = new System.Drawing.Point(24, 66);
            this.valueBox.Name = "valueBox";
            this.valueBox.Size = new System.Drawing.Size(100, 22);
            this.valueBox.TabIndex = 49;
            this.valueBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(84, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 14);
            this.label6.TabIndex = 50;
            this.label6.Text = "결과값";
            // 
            // caliBox
            // 
            this.caliBox.Location = new System.Drawing.Point(29, 50);
            this.caliBox.Name = "caliBox";
            this.caliBox.Size = new System.Drawing.Size(100, 22);
            this.caliBox.TabIndex = 51;
            this.caliBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cycleBox
            // 
            this.cycleBox.Location = new System.Drawing.Point(29, 98);
            this.cycleBox.Name = "cycleBox";
            this.cycleBox.Size = new System.Drawing.Size(100, 22);
            this.cycleBox.TabIndex = 52;
            this.cycleBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // 캘리값
            // 
            this.캘리값.AutoSize = true;
            this.캘리값.ForeColor = System.Drawing.Color.White;
            this.캘리값.Location = new System.Drawing.Point(89, 33);
            this.캘리값.Name = "캘리값";
            this.캘리값.Size = new System.Drawing.Size(40, 14);
            this.캘리값.TabIndex = 53;
            this.캘리값.Text = "캘리값";
            // 
            // 반복횟수
            // 
            this.반복횟수.AutoSize = true;
            this.반복횟수.ForeColor = System.Drawing.Color.White;
            this.반복횟수.Location = new System.Drawing.Point(80, 81);
            this.반복횟수.Name = "반복횟수";
            this.반복횟수.Size = new System.Drawing.Size(51, 14);
            this.반복횟수.TabIndex = 54;
            this.반복횟수.Text = "반복횟수";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.changeCycle);
            this.groupBox1.Controls.Add(this.cycleBox);
            this.groupBox1.Controls.Add(this.반복횟수);
            this.groupBox1.Controls.Add(this.caliBox);
            this.groupBox1.Controls.Add(this.캘리값);
            this.groupBox1.Controls.Add(this.changeCali);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(162, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(248, 158);
            this.groupBox1.TabIndex = 55;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Setting값";
            // 
            // changeCycle
            // 
            this.changeCycle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.changeCycle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.changeCycle.Font = new System.Drawing.Font("나눔스퀘어_ac", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.changeCycle.ForeColor = System.Drawing.Color.White;
            this.changeCycle.Location = new System.Drawing.Point(144, 82);
            this.changeCycle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.changeCycle.Name = "changeCycle";
            this.changeCycle.Size = new System.Drawing.Size(88, 38);
            this.changeCycle.TabIndex = 55;
            this.changeCycle.Text = "적용하기";
            this.changeCycle.UseVisualStyleBackColor = true;
            this.changeCycle.Click += new System.EventHandler(this.changeCycle_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.writeBox);
            this.groupBox2.Controls.Add(this.receiveBox);
            this.groupBox2.Controls.Add(this.textBox12);
            this.groupBox2.Controls.Add(this.errorBoxCon);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.errorBox);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(162, 227);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(191, 212);
            this.groupBox2.TabIndex = 56;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "체크기능";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(39, 113);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 57;
            this.button1.Text = "에러체크";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // adress06
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(434, 221);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.valueBox);
            this.Controls.Add(this.timer06Stop);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("나눔스퀘어_ac", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "adress06";
            this.Text = "ADC Checker";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer responseTimer;
        private System.Windows.Forms.TextBox receiveBox;
        private System.Windows.Forms.TextBox writeBox;
        private System.Windows.Forms.TextBox errorBox;
        private System.Windows.Forms.Button changeCali;
        private System.Windows.Forms.Timer timer03;
        private System.Windows.Forms.Button timer06Stop;
        private System.Windows.Forms.TextBox errorBoxCon;
        private System.Windows.Forms.Timer timerWait;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 파일ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 종료ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 포트설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 로그확인ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox valueBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox caliBox;
        private System.Windows.Forms.TextBox cycleBox;
        private System.Windows.Forms.Label 캘리값;
        private System.Windows.Forms.Label 반복횟수;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button changeCycle;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
    }
}

